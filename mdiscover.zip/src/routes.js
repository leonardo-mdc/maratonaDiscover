const express = require('express');
const routes = express.Router()


// basePath -- definie caminho base usando constante __dirname
const views = __dirname + "/views/"

// objeto para o profile
const Profile = {
  data: {
    name: "Leonardo Carvalho",
    avatar: "https://github.com/leonardo-mdc.png",
    "monthly-budget": 3000,
    "days-per-week": 5,
    "hours-per-day": 5,
    "vacation-per-year": 3,
    "value-hour": 75
  },

  controllers: {
    index(req, res) {
      return res.render(views + "profile", { profile: Profile.data })
    },

    update(req, res) {
      // req.body para pegar os dados
      const data = req.body

      // definir quantas semanas tem num ano (52)
      const weeksPerYear = 52

      // remover as semanas de férias do ano, para pegar quantas semanas em 1 mês
      const weeksPerMonth = (weeksPerYear - data["vacation-per-year"]) / 12

      // quantas horas por semana estou trabalhando
      const weekTotalHours = data["hours-per-day"] * data["days-per-week"]

      // total das horas trabalhadas no mês
      const montlhyTotalHours = weekTotalHours * weeksPerMonth

      // qual será o valor da minha hora
      const valueHour = data["monthly-budget"] / montlhyTotalHours

      Profile.data = {
        ...Profile.data,
        ...req.body,
        "value-hour": valueHour
      }

      return res.redirect('/profile')
    }
  }
}

//objeto literal

const Job = {
  data: [
    {
      id: 1,
      name: "Pizzaria Guloso",
      "daily-hours": 2,
      "total-hours": 1,
      createdAt: Date.now()
    },
    {
      id: 2,
      name: "OneTwo Project",
      "daily-hours": 3,
      "total-hours": 47,
      createdAt: Date.now()
    },
    {
      id: 3,
      name: "Jobomas",
      "daily-hours": 8,
      "total-hours": 47,
      createdAt: Date.now()
    }
  ],

  controllers: {
    index(req, res) {
      const updatedJobs = Job.data.map((job) => {
        //ajustes no job
        const remaining = Job.services.remainingDays(job)
        const status = remaining <= 0 ? 'done' : 'progress'

        return {
          ...job,
          remaining,
          status,
          budget: Job.services.calculateBudget(job, Profile.data["value-hour"])
        }
      })

      return res.render(views + "index", { jobs: updatedJobs })

    },

    create(req, res) {
      return res.render(views + "job")
    },

    save(req, res) {
      // { name: 'Leonardo Carvalho', 'daily-hours': '11', 'total-hours': '11111' }
      const lastId = Job.data[Job.data.length - 1]?.id || 1;

      Job.data.push({
        id: lastId + 1,
        name: req.body.name,
        "daily-hours": req.body["daily-hours"],
        "total-hours": req.body["total-hours"],
        created_at: Date.now() // data de hoje
      })

          return res.redirect('/')
    },

    show(req, res) { 

      const jobId = req.params.id

      const job = Job.data.find( job => Number(job.id) === Number(jobId))

      if (!job) {
        return res.send("Job not found!")
      } 

      job.budget = Job.services.calculateBudget(job, Profile.data["value-hour"])

      return res.render(views + "job-edit", { job })
    },
    
    show(req, res) { 

      const jobId = req.params.id

      const job = Job.data.find( job => Number(job.id) === Number(jobId))

      if (!job) {
        return res.send("Job not found!")
      } 

      constupdatedJob = {
        ...job,
        name: req.body.name,
        "total-hours": req.body["total-hours"],
        "daily-hours": req.body["daily-hours"],

      }

      job.budget = Job.services.calculateBudget(job, Profile.data["value-hour"])

      return res.render(views + "job-edit", { job })
    },
  },

  services: {
    remainingDays(job) {
      // ajustes no job
      // cálculo de tempo restante
      const remainingDays = (job["total-hours"] / job["daily-hours"]).toFixed()

      const createdDate = new Date(job.createdAt)
      const dueDay = createdDate.getDate() + Number(remainingDays)
      const dueDateInMs = createdDate.setDate(dueDay)

      const timeDiffInMs = dueDateInMs - Date.now()
      // transformar milli em dias
      const dayInMs = 1000 * 60 * 60 * 24
      const dayDiff = Math.floor(timeDiffInMs / dayInMs)

      // restam x dias
      return dayDiff
    },
    calculateBudget: (job, valueHour) => valueHour * job["total-hours"]
  },

}


// gera rotas
routes.get('/', Job.controllers.index)

routes.get('/job', Job.controllers.create)
routes.post('/job', Job.controllers.save)
routes.get('/job/:id', Job.controllers.show)
routes.post('/job/:id', Job.controllers.update)

routes.get('/profile', Profile.controllers.index)
routes.get('/profile', Profile.controllers.update)
routes.post('/profile', Profile.controllers.update)


module.exports = routes;